package com.truist.dre.batch.app.batch;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.truist.dre.batch.app.model.AccountDO;
import com.truist.dre.batch.app.repository.UserRepository;

import java.util.List;

@Component
public class DBWriter implements ItemWriter<AccountDO> {

    private UserRepository userRepository;

    @Autowired
    public DBWriter (UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void write(List<? extends AccountDO> users) throws Exception{
        System.out.println("Data Saved for Users: " + users);
        //userRepository.saveAll(users);
    }
}
