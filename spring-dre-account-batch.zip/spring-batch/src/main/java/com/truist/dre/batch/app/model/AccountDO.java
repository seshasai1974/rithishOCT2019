package com.truist.dre.batch.app.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class AccountDO {

    @Id
    private Integer accountNumber;


    public AccountDO(Integer accountNumber) {
        this.accountNumber = accountNumber;

    }

    public AccountDO() {
    }

    public Integer getId() {
        return accountNumber;
    }


    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("AccountDO{");
        sb.append("accountNumber=").append(accountNumber);

        sb.append('}');
        return sb.toString();
    }

}
