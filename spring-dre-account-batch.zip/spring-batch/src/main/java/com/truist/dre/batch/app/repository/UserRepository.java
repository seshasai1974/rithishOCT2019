package com.truist.dre.batch.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truist.dre.batch.app.model.AccountDO;

public interface UserRepository extends JpaRepository<AccountDO, Integer> {
}
