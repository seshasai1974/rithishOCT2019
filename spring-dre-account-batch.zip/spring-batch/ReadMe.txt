Load CSV to DB

•http://localhost:8081/load - Trigger point for Spring Batch
•http://localhost:8081/h2-console - H2 Console for querying the in-memory tables.

H2 Config

•jdbc:h2:mem:testdb - Database
•sa - User
•password - Password.
