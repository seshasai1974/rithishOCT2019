package com.dbspdfbox;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDButton;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDNonTerminalField;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;

public class DBSReadAllFormFields {

	public static void main(String[] args) throws InvalidPasswordException, IOException {
		try {
			File myFile = new File("src/main/resources/treasures-non-resident-individual-account-opening-form.pdf");

			System.out.println(" myFile : " + myFile);
			PDDocument pdfDocument = PDDocument.load(myFile);
			PDDocumentCatalog docCatalog = pdfDocument.getDocumentCatalog();
			PDAcroForm acroForm = docCatalog.getAcroForm();
			List<PDField> fields = acroForm.getFields();
			PDField myfield = acroForm.getField("topmostSubform[0].Page1[0].Mr[0]");
			PDField myfield1 = acroForm.getField("topmostSubform[0].Page1[0].undefined_2[0]");
			PDField myfield2 = acroForm.getField("topmostSubform[0].Page1[0].undefined[0]");
			PDField myfield3 = acroForm.getField("topmostSubform[0].Page1[0].Pl_specify[0]");
			
			System.out.println(" --- " +myfield3.getClass());
			if (myfield2 instanceof PDTextField) {
				System.out.println(" PDTextField 1 encountered ---- ");
				PDTextField textField = (PDTextField)myfield2;
				textField.setValue("ARCOT ETHIRAJULU");
			}
			if (myfield1 instanceof PDTextField) {
				System.out.println(" PDTextField encountered ---- ");
				PDTextField textField = (PDTextField)myfield1;
				textField.setValue("SESHASAI VENKAT");
			}

			if (myfield instanceof PDCheckBox) {
				System.out.println(" checkbox encountered ---- ");
				PDCheckBox chkbox = (PDCheckBox) myfield;

				//System.out.println("before " + chkbox.getValue());
				chkbox.check();
				//System.out.println("after " + chkbox.getValue());
				// chkbox.unCheck();;
				// System.out.println("after 1 " + chkbox.getValue());
			}
			// set the button to true
			pdfDocument.save("src/main/resources/output.pdf");

			
			  for (PDField field : fields) 
			  { 
				  list(field); 
			  }
			 
			pdfDocument.close();

		} finally {

		}

	}

	static void list(PDField field) {
		//System.out.println(field.getFullyQualifiedName());
		//System.out.println(field.getFieldType());

		if (field instanceof PDNonTerminalField) {
			PDNonTerminalField nonTerminalField = (PDNonTerminalField) field;
			for (PDField child : nonTerminalField.getChildren()) {
				//System.out.println(" ** ");
				list(child);
			}
		}
	}

}
