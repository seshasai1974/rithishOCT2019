package com.dbspdfbox;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

public class DBSPdfBoxUpdateExample {

	public static void main(String[] args) {

		PDDocument document = null;
		try {
		    document = PDDocument.load(new File("/x/x/x/mypdf.pdf"));
		    PDPage page = (PDPage) document.getDocumentCatalog().getPages().get(0);
		    PDFont font = PDType1Font.HELVETICA_BOLD;
		    //PDPageContentStream contentStream = new PDPageContentStream(document, page);
		    PDPageContentStream contentStream = new PDPageContentStream(document, page, true, true);

		    page.getContents().readAllBytes();
		    contentStream.beginText();
		    contentStream.setFont(font, 12);
		    contentStream.moveTextPositionByAmount(100, 100);
		    contentStream.drawString("Hello");
		    contentStream.endText();
		    contentStream.close();
		    document.save("/x/x/x/mypdf.pdf");
		    document.close();
		} catch (IOException e) {
		    e.printStackTrace();
		} 
	}

}
