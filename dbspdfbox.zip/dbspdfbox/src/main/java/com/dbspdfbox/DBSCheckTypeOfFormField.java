package com.dbspdfbox;

import java.io.File;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDButton;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDComboBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDPushButton;
import org.apache.pdfbox.pdmodel.interactive.form.PDRadioButton;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;

public class DBSCheckTypeOfFormField {
	public static void listFields(PDDocument doc) throws Exception
	{
	    PDDocumentCatalog catalog = doc.getDocumentCatalog();
	    PDAcroForm form = catalog.getAcroForm();
	    List<PDField> fields = form.getFields();

	    for(PDField field: fields)
	    {
	        String name = field.getFullyQualifiedName();
	        if (field instanceof PDTextField || field instanceof PDComboBox)
	        {
	             Object value = field.getValueAsString();
	             System.out.print(name);
	             System.out.print(" = ");
	             System.out.print(value);
	             System.out.println();
	        }
	        else if (field instanceof PDPushButton)
	            ;
	        else
	        {
	            if (field instanceof PDRadioButton)
	            {
	                PDRadioButton radioButton = (PDRadioButton)form.getField(name);
	                String value=radioButton.getValue();
	                System.out.print(name);
	                System.out.print(" = ");
	                System.out.print(value);
	                System.out.println();
	                /*List<String> exportValues = ((PDRadioButton) field).getSelectedExportValues();
	                for (String string : exportValues)
	                {
	                    name = field.getFullyQualifiedName();
	                    System.out.print(name);
	                    System.out.print(" = ");
	                    System.out.print(string);
	                    System.out.println();
	                } */
	            }
	            else if (field instanceof PDCheckBox)
	            {
	                PDButton box = (PDButton)field;
	                String value = box.getValue();
	                System.out.print(name);
	                System.out.print(" = ");
	                System.out.print(value);
	                System.out.println();
	            }

	        }
	    }
	}

	public static void main(String[] args) throws Exception {
	    File file = new File("C:\\Users\\bobdu\\Documents\\SHIP_CCF_LastName_FirstName_YYYYMMDD_v1_Sample.pdf");
	    PDDocument doc = PDDocument.load(file);
	    listFields(doc);
	}

}
