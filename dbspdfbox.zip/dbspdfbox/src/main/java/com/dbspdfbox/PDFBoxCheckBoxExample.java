package com.dbspdfbox;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;

public class PDFBoxCheckBoxExample {

	public static void main(String[] args) throws InvalidPasswordException, IOException {
		PDDocument fdeb = null;
		File file = new File("");

        fdeb = PDDocument.load(file);

         PDAcroForm form = fdeb.getDocumentCatalog().getAcroForm();
         PDField feld3 = form.getField("loan");
         ((PDCheckBox) feld3).check();


         fdeb.save("C:\\Users\\34\\Desktop\\complaintform.pdf");
         fdeb.close();


	}

}
