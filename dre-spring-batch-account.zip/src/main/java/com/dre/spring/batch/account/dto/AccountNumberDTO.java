package com.dre.spring.batch.account.dto;

import lombok.Data;


public class AccountNumberDTO {

    private String accountNumber;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


}
