package com.dre.spring.batch.account.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.dre.spring.batch.account.dto.AccountNumberDTO;
import com.dre.spring.batch.account.model.AccountNumber;

import java.util.Random;

@Component
public class AccountNumberProcessor implements ItemProcessor<AccountNumberDTO, AccountNumber> {

    @Override
    public AccountNumber process(AccountNumberDTO employeeDTO) throws Exception {
        AccountNumber accountNumber = new AccountNumber();
        
        //call NewAccountLoadService.processMessage(String accountNumber)
        
        System.out.println("inside AccountNumberProcessor " + accountNumber.toString());
        return accountNumber;
    }
}
