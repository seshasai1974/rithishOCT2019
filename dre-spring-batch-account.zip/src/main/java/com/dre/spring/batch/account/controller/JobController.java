package com.dre.spring.batch.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dre.spring.batch.account.runner.JobRunner;

/*
url: http://localhost:8080/run/accounts
 */

@RestController
@RequestMapping("/run")
public class JobController {

    private JobRunner jobRunner;

    @Autowired
    public JobController(JobRunner jobRunner) {
        this.jobRunner = jobRunner;
    }

    @RequestMapping(value = "/accounts")
    public String runJob() {
        jobRunner.runBatchJob();
        return String.format("Account Reading and Processing Job submitted successfully.");
    }
}
