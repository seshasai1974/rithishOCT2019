package com.dre.spring.batch.account.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import com.dre.spring.batch.account.dto.AccountNumberDTO;
import com.dre.spring.batch.account.mapper.AccountNumberRowMapper;
import com.dre.spring.batch.account.model.AccountNumber;
import com.dre.spring.batch.account.processor.AccountNumberProcessor;

import javax.sql.DataSource;

@Configuration
public class AsyncJobRunner {

    private JobBuilderFactory jobBuilderFactory;
    private StepBuilderFactory stepBuilderFactory;
    private AccountNumberProcessor accountNumberProcessor;
 

    @Autowired
    public AsyncJobRunner(JobBuilderFactory jobBuilderFactory, 
    		              StepBuilderFactory stepBuilderFactory, 
    		              AccountNumberProcessor accountProcessor) {
        this.jobBuilderFactory = jobBuilderFactory;
        this.stepBuilderFactory = stepBuilderFactory;
        this.accountNumberProcessor = accountProcessor;
    }

    @Qualifier(value = "account")
    @Bean
    public Job demo4Job() throws Exception {
        return this.jobBuilderFactory.get("account")
                .start(stepReadAsync())
                .build();
    }

    @Bean
    public Step stepReadAsync() throws Exception {
        return this.stepBuilderFactory.get("stepReadProcessWrite")
                .<AccountNumberDTO, AccountNumber>chunk(10)
                .reader(accountReader())
                .processor(accountNumberProcessor)
                .writer(udmFileWriter())
                .taskExecutor(taskExecutor())
                .build();
    }

    @Bean
    @StepScope
    Resource inputFileResource(@Value("#{jobParameters[fileName]}") final String fileName) throws Exception {
        return new ClassPathResource(fileName);
    }

    @Bean
    @StepScope
    public FlatFileItemReader<AccountNumberDTO> accountReader() throws Exception {
        FlatFileItemReader<AccountNumberDTO> reader = new FlatFileItemReader<>();
        reader.setResource(inputFileResource(null));
        reader.setLineMapper(new DefaultLineMapper<AccountNumberDTO>() {{
            setLineTokenizer(new DelimitedLineTokenizer() {{
                setNames("accountNumber");                
            }});
            setFieldSetMapper(new AccountNumberRowMapper());
        }});
        return reader;
    }

    @Bean
    public FlatFileItemWriter<AccountNumber> udmFileWriter() {
    	FlatFileItemWriter<AccountNumber> itemWriter = new FlatFileItemWriter<AccountNumber>();
       return itemWriter;
    }

    @Bean
    public TaskExecutor taskExecutor(){
        SimpleAsyncTaskExecutor simpleAsyncTaskExecutor = new SimpleAsyncTaskExecutor();
        simpleAsyncTaskExecutor.setConcurrencyLimit(7);
        return simpleAsyncTaskExecutor;
    }



}
