package com.dre.spring.batch.account.mapper;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;

import com.dre.spring.batch.account.dto.AccountNumberDTO;

public class AccountNumberRowMapper implements FieldSetMapper<AccountNumberDTO> {

    @Override
    public AccountNumberDTO mapFieldSet(FieldSet fieldSet) {
        AccountNumberDTO employee = new AccountNumberDTO();
        
        return employee;
    }

}
